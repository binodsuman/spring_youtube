package binod.suman.student_mvc_orm.config.dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import binod.suman.student_mvc_orm.config.entity.Student;

public class StudentDAO {
	
	private HibernateTemplate hibernateTemplate;

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
     public void insert(Student student) {
    	 hibernateTemplate.save(student);
     }

     public void update(Student student) {
    	 hibernateTemplate.update(student);
     }
     
     public Student getStudent(int roll) {
    	 return hibernateTemplate .get(Student.class, roll);
     }
     
     public void delete(int roll) {
    	 hibernateTemplate.delete(getStudent(roll));
     }
     
     public List<Student> getAllStudents(){
    	 return (List<Student>) hibernateTemplate.find("from Student");
     }
	
}

package binod.suman.mvc_result.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import binod.suman.mvc_result.entity.Student;

@Controller
@RequestMapping("/result")
public class StudentController {
	
	@RequestMapping(method=RequestMethod.POST)
	public String studentResult(Model model, Student student) {
		
		System.out.println("Student Roll :"+student.getRoll());
		System.out.println("Student Name :"+student.getName());
		
		int roll = student.getRoll();
		
		if(roll == 110) {
			student.setMath(90);
			student.setPhysics(70);
		}
		
		else if(roll == 120) {
			student.setMath(90);
			student.setPhysics(80);
		}
		
		
		student.setTotal(student.getMath() + student.getPhysics());;
		System.out.println("Student Roll :"+student.getRoll());
		System.out.println("Student Name :"+student.getName());
		
		model.addAttribute(student);
		
		return "showResult";
	}

}

package binod.suman.Client_First;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}

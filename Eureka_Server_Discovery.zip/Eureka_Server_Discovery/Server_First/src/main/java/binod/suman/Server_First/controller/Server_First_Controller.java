package binod.suman.Server_First.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Server_First_Controller {
	
	@GetMapping("/homeserver")
	public String home() {
		return "<h1>This is Home page for Server First</h1>";
	}
	
	@GetMapping("/user")	
	public String user() {
		return "<h1>This is User page for Server First</h1>";
	}
	
	@GetMapping("/admin")	
	public String admin() {
		return "<h1>This is Admin page for Server First</h1>";
	}
	

}

package binod.suman.DEMO_AOP.aop;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class AspectDemo {
	
	//@Before("execution(* binod.suman.DEMO_AOP.service.Admission.saveStudent() )")
	//@Before("execution(* binod.suman.DEMO_AOP.service.Admission.saveStudent(..) )")
	//@Before("execution(* binod.suman.DEMO_AOP.service.Admission.*(..) )")
	@Before("execution(* binod.suman.DEMO_AOP.service.*.*(..) )")
	public void logBeforeExecution() {
		System.out.println("Admission is being started from ASPECT ADVICE");
	}
	
	@After("execution(* binod.suman.DEMO_AOP.service.*.*(..) )")
	public void logAfterExecution() {
		System.out.println("Admission is being done from ASPECT ADVICE");
	}
	
	@AfterThrowing("execution(* binod.suman.DEMO_AOP.service.*.*(..) )")
	public void logError() {
		System.out.println("****** SOME ERROR ENCOUNTERED  ********");
	}

}
 
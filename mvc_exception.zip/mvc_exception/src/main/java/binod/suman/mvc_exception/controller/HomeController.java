package binod.suman.mvc_exception.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	private String name = "Binod Suman";
	
	@RequestMapping(value="/")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		
		ModelAndView mv = new ModelAndView("home");
		mv.addObject("name", name.substring(5,15));
		return mv;
	}
	
	@ExceptionHandler({Exception.class})
	public String errorHandler() {
		return "error";
	}
}

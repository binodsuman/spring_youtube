package binod.suman.hystrix_demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@RestController
public class HystrixController {
	
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/home")	
	public String base() {
		return "<h1>This is Home page for Hystrix Server</h1>";
	}
	
	
	@GetMapping("/firstdemo")
	public String cartPurchase() {
		String first = restTemplate.getForObject("http://localhost:8081/order", String.class);
		String second = restTemplate.getForObject("http://localhost:8082/product", String.class);
		return first+" "+second;
	}
	
	@HystrixCommand(fallbackMethod = "myFallBackMethod")
	@GetMapping("/seconddemo")
	public String cartPurchaseHandle() {
		String first = restTemplate.getForObject("http://localhost:8081/order", String.class);
		String second = restTemplate.getForObject("http://localhost:8082/product", String.class);
		return first+" "+second;
	}
	
	@HystrixCommand(fallbackMethod = "myFallBackMethod", commandProperties = {
		      @HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "1000")
		   })
	@GetMapping("/thirddemo")
	public String purchaseTimerTest() throws InterruptedException {
		String first = restTemplate.getForObject("http://localhost:8081/user", String.class);
		Thread.sleep(2000);
		String second = restTemplate.getForObject("http://localhost:8082/admin", String.class);
		return first+" "+second;
	}
	
	public String myFallBackMethod() {
		return "<h1>Hello User, please come back in 10 mintures</h1>";
	}

}

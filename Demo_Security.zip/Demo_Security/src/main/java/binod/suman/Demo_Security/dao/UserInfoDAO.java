package binod.suman.Demo_Security.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import binod.suman.Demo_Security.entity.UserInfo;

@Repository
public interface UserInfoDAO extends JpaRepository<UserInfo, Integer>{

	UserInfo findUserByUsername(String username);
}

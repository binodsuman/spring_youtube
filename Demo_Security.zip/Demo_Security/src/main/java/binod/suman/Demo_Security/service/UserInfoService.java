package binod.suman.Demo_Security.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import binod.suman.Demo_Security.dao.UserInfoDAO;
import binod.suman.Demo_Security.entity.UserInfo;

@Service
public class UserInfoService implements UserDetailsService{

	@Autowired
	private UserInfoDAO dao;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	    UserInfo user = dao.findUserByUsername(username);
		System.out.println("User in Service Layer :"+user);
		if(user == null) {
			throw new UsernameNotFoundException("This user does not exist");
		}
		return user;
	}
}

package binod.suman.spring_security_demo_first;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityDemoFirstApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityDemoFirstApplication.class, args);
	}

}

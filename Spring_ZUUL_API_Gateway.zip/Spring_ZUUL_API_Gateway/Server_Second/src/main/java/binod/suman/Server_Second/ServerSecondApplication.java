package binod.suman.Server_Second;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerSecondApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerSecondApplication.class, args);
	}

}

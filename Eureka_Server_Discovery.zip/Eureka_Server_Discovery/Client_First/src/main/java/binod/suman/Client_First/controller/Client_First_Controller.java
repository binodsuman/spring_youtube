package binod.suman.Client_First.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class Client_First_Controller {
	
	static final String SEVER_FIRST_URL = "http://SERVER-FIRST/";
	
	
	@Bean
	@LoadBalanced
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
	@Autowired
	public RestTemplate restTemplate;
	
	
	@GetMapping("/home")	
	public String base() {
		return "<h1>This is Home page for Client First</h1>";
	}
	
	@GetMapping("/user")	
	public String user() {
		return "<h1>This is User page for Client First</h1>";
	}
	
	@GetMapping("/admin")	
	public String admin() {
		return "<h1>This is Admin page for Client First</h1>";
	}
	
	@GetMapping("/connectserver")
	public String serverFirstConnect() {
		return restTemplate.getForObject(SEVER_FIRST_URL+"homeserver", String.class);
	}

}

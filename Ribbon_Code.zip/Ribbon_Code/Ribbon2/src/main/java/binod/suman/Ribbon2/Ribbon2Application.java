package binod.suman.Ribbon2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ribbon2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ribbon2Application.class, args);
	}

}

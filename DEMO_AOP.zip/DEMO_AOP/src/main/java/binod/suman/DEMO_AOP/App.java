package binod.suman.DEMO_AOP;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import binod.suman.DEMO_AOP.service.Admission;
import binod.suman.DEMO_AOP.service.Fee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		
        Admission admission = (Admission)context.getBean("add");
        Fee fee = (Fee)context.getBean("fee");
        admission.saveStudent(110);
        System.out.println("************************");
        admission.hostelAllocated();
        System.out.println("********************");
        fee.saveStudent(110);
        
    }
}

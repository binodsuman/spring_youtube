package binod.suman.student_mvc_orm.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import binod.suman.student_mvc_orm.config.dao.StudentDAO;
import binod.suman.student_mvc_orm.config.entity.Student;

@Controller
public class HomeController {

	@Autowired
	StudentDAO dao;
	
	
	@RequestMapping(value="/studentform")
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("studentform");
	}
	
	@RequestMapping("/viewstudent")  
    public String viewemp(Model m){  
        List<Student> list=dao.getAllStudents();  
        m.addAttribute("list",list);
        System.out.println("Number of Record :"+list.size());
        return "viewstudent";  
    } 
	
	@RequestMapping(value="/save",method = RequestMethod.POST)  
    public String save(@ModelAttribute("student") Student student){ 
		System.out.println("One Student Record is being saved.");
		System.out.println(student);
        dao.insert(student);  
        return "redirect:/viewstudent";  
    }  
	
	
	@RequestMapping(value="/editstudent/{roll}")  
    public String edit(@PathVariable int roll, Model m){  
        Student student = dao.getStudent(roll);
        m.addAttribute("command",student);
        return "studenteditform";  
    }  
	
	@RequestMapping(value="/editsave",method = RequestMethod.POST)  
    public String editsave(@ModelAttribute("student") Student student){  
		System.out.println("Edit save :"+student);
        dao.update(student);  
        return "redirect:/viewstudent";  
    } 
	
	@RequestMapping(value="/deletestuent/{roll}",method = RequestMethod.GET)  
    public String delete(@PathVariable int roll){  
        dao.delete(roll);  
        return "redirect:/viewstudent";  
    }
	
	
}

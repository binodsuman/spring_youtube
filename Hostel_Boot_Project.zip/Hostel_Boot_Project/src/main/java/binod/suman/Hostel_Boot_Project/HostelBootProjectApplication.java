package binod.suman.Hostel_Boot_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HostelBootProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HostelBootProjectApplication.class, args);
	}

}

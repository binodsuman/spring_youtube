package binod.suman.order_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

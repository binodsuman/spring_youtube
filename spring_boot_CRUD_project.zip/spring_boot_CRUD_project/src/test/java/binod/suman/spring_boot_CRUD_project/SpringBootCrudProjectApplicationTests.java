package binod.suman.spring_boot_CRUD_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

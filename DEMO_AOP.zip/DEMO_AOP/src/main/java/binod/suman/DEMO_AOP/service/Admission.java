package binod.suman.DEMO_AOP.service;

public class Admission {
	
	public void saveStudent(int enrollmentNumber) {
		System.out.println("New Student entry started");
		//
		//
		//
		//
		//
		System.out.println("New Student record saved in Database");
	}
	
	public void hostelAllocated() {
		System.out.println("Hostel is being searched");
		//
		//
	   System.out.println("New Student record saved in Database");	
	}

}

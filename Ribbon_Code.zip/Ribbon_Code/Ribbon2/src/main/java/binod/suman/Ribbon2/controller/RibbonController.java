package binod.suman.Ribbon2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RibbonClient(name="RibbonDemo")
public class RibbonController {
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/home")
	public String ribbonHome() {
		return "<h1>This is Ribbon Home page</h1>";
	}
	
	// "loadbalancerserver" should match with application.properties loadbalancerserver word.
	@GetMapping("/callproduct")
	public String callProduct() {
		//String url = "http://localhost:8081/user";
		String url = "http://loadbalancerserver/user";
		return restTemplate.getForObject(url, String.class);
	}
	
	

}

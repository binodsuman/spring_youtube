package binod.suman.spring_security_demo_first;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityDemoFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}

package binod.suman.spring_boot_first_demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//@Controller for MVC, use review resolver
@RestController
public class StudentController {

	 @RequestMapping("home")
	 public String home() {
		 return "This is my first REST API, time :"+ new java.util.Date();
	 }
	 
	//@RequestMapping(value="search/{roll}",method=RequestMethod.GET)
	@GetMapping(value="search/{roll}")
		public String search(@PathVariable int roll) {
			if(roll == 110) {
				return "Student name is Binod Suman";
			}
			else {
				return "Student name is Bill Gates";
			}
		}
	
	@RequestMapping(value="find")
	public String find(@RequestParam(value="roll") int roll) {
		if(roll == 110) {
			return "Student name is Binod Suman [Using RequestParam]";
		}
		else {
			return "Student name is Bill Gates [Using RequestParam]";
		}
	}
	
	@PostMapping(value="findByName")
	public String findByName(@RequestBody String name) {
		System.out.println(name);
		if(name.equalsIgnoreCase("Binod")) {
			return "Student Full name is Binod Suman and Roll number is 110";
		}
		else if(name.equalsIgnoreCase("bill")) {
			return "Student Full name is Bill Gates and Roll number is 120";
		}
		else {
			return "This name is not there in Database";
		}
	}
}

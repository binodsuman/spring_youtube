package binod.suman.Ribbon2;

//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ribbon2ApplicationTests {

//	@Test
	void contextLoads() {
	}

}

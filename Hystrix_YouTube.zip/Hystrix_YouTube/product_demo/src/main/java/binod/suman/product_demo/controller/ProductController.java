package binod.suman.product_demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	
	@GetMapping("/home")
	public String home() {
		return "<h1>This is Home page for Product Server</h1>";
	}
	
	@GetMapping("/product")
	public String product() {
		return "<h1>This is Product page for Product Server</h1>";
	}

}

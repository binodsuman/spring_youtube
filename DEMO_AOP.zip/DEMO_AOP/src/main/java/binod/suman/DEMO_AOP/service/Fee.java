package binod.suman.DEMO_AOP.service;

public class Fee {
	
	public void saveStudent(int enrollmentNumber) {
		System.out.println("New Student entry started FEE");
		//
		String name  = "Binod";
		name.substring(5,10);
				
		//
		//
		//
		System.out.println("New Student record saved in Database FEE");
	}
	
	public void hostelAllocated() {
		System.out.println("Hostel is being searched FEE");
		//
		//
	   System.out.println("Hostel allcoated to Student FEE");	
	}

}
